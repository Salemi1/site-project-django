from django.shortcuts import render, redirect
from django.http import HttpResponse
from django.core import mail
from django.contrib.auth import authenticate,login,logout
import os,sys
from .forms import *
from .models import *
NAME="Shop"
LOGIN=False
USERNAME=None
x=5

AD=ADModel.objects.all()

main_dec={
    "name": NAME,
    "login":LOGIN,
    "username": USERNAME,
    "ad":AD,
    "clear":False,
}

def home(req):
    global x,AD
    AD=ADModel.objects.all()
    if 'left' in req.POST:
        form1=Form1(req.POST)
        if form1.is_valid():
            x-=1
    if 'right' in req.POST:
        form1=Form1(req.POST)
        if form1.is_valid():
            x+=1
    else:
        form1=Form1()

    dec={
        "form1" : form1,
        "x" : x,
    }

    return render(req,"home.html",{**dec,**main_dec})

def ajnas(req):
    dec={
        "ajnas": KafshModel.objects.all(),
    }
    return render(req,"ajnas.html",{**dec,**main_dec,'clear':True})

def jens(req,code):
    kafsh=KafshModel.objects.all()[int(code)-1]
    dec={
        "code":code,
        "kafsh":kafsh,
        "emtiaz":str(randint(26,50)/10)[:3],
    }
    return render(req,"jens.html",{**dec,**main_dec})

def buy(req,code):
    if LOGIN:
        k=KafshModel.objects.all()[int(code)-1]
        for i in UserModel.objects.all():
            if i.username==USERNAME:
                i.sabad=str(i.sabad)[:-1]+'\''+str(k.model)+'_'+str(k.size)+'_'+str(k.color)+'_'+str(k.price)+'\''+', '+']'
                i.save()
        return redirect("factor")
    else:
        return redirect("login")

def factor(req):
    if LOGIN:
        for i in UserModel.objects.all():
            if i.username==USERNAME:
                dec={
                    'sabad':list( map(lambda a:a.split('_'),eval(i.sabad)) ),
                    }
                return render(req,"factor.html",{**dec,**main_dec})
    else:
        return redirect("login")

def pardakht(req):
    for i in UserModel.objects.all():
        if i.username==USERNAME:
            i.sabad='[]'
            i.save()
            return redirect('factor')

def text(req):
    dec={
    }
    return render(req,"text.html",{**dec,**main_dec})

def callme(req):
    return render(req,"call.html",{**main_dec})

def aboutme(req):
    return render(req,"about.html",{**main_dec})

def login(req):
    global main_dec,LOGIN,USERNAME
    error=False
    if 'sabt' in req.POST:
        form=Form3(req.POST)
        if form.is_valid():
            for i in UserModel.objects.all():
                if i.username==str(form.cleaned_data['username']) and i.password==str(form.cleaned_data['password']):
                    error=False
                    LOGIN=True
                    USERNAME=i.username
                    main_dec['login']=True
                    main_dec['username']=USERNAME
                    return redirect("home")
            else:
                error=True
    else:
        form=Form3()
    dec={
        'form3': form,
        'error': error,
    }
    return render(req,"login.html",{**dec,**main_dec})

def signin(req):
    if "sabt" in req.POST:
        form=Form2(req.POST)
        if form.is_valid():
            username=form.cleaned_data['username']
            email=form.cleaned_data['email']
            password=form.cleaned_data['password']
            UserModel.objects.create(username=username,email=email,password=password)
            return redirect("login")
    else:
        form=Form2()

    dec={
        "form2":form,
    }

    return render(req,"sabt.html",{**dec,**main_dec})